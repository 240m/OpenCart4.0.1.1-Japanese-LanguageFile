<?php
// Heading
$_['heading_title']    = '信用取引(後払い)';

// Text
$_['text_extension']       = '拡張機能';
$_['text_success']     = '成功: 信用取引を更新しました!';
$_['text_edit']        = '信用取引(後払い)の編集';

// Entry
$_['entry_status']     = 'ステータス';
$_['entry_sort_order'] = '表示順';

// Error
$_['error_permission'] = '警告: 信用取引を更新する権限がありません!';
