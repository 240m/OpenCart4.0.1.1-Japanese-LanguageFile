<?php
$_['text_subject'] = '%s - 注文 %s';
$_['text_greeting'] = 'この度は、%s製品にご興味をお持ちいただき、ありがとうございます。ご注文を承りましたので、ご入金の確認が取れ次第、処理を開始いたします。';
$_['text_link'] = 'ご注文内容を確認するには、以下のリンクをクリックしてください：';
$_['text_order_detail'] = '注文の詳細';
$_['text_instruction'] = '使用方法';
$_['text_order_id'] = 'オーダーIDです：';
$_['text_date_added'] = '日付が追加されました：';
$_['text_order_status'] = '注文状況です：';
$_['text_payment_method'] = '支払い方法について';
$_['text_shipping_method'] = '発送方法について：';
$_['text_email'] = '電子メール';
$_['text_telephone'] = '電話番号';
$_['text_ip'] = 'IPアドレスです：';
$_['text_payment_address'] = '支払先住所';
$_['text_shipping_address'] = '配送先住所';
$_['text_products'] = '製品紹介';
$_['text_product'] = '製品';
$_['text_model'] = 'モデル';
$_['text_quantity'] = '数量';
$_['text_price'] = '価格';
$_['text_order_total'] = '注文の集計';
$_['text_total'] = '合計';
$_['text_download'] = 'ご入金確認後、以下のリンクをクリックすると、ダウンロード可能な製品にアクセスすることができます：';
$_['text_comment'] = 'ご注文時のコメントです：';
$_['text_footer'] = 'ご不明な点がございましたら、このメールにご返信ください。';
?>
