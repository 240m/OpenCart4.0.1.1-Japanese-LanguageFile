<?php
$_['text_language'] = '言語';
?>
