<?php
// Text
$_['text_subject']       = '%s 返品状況のお知らせ No: %s';
$_['text_return_id']     = '返品番号:';
$_['text_date_added']    = 'ご依頼日:';
$_['text_return_status'] = '現在の処理状況:';
$_['text_comment']       = 'コメント:';
$_['text_footer']        = 'ご質問がございましたら、当店までメールにてお問合せください。';
