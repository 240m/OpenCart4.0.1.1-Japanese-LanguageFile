<?php
$_['text_success'] = '成功です：あなたは命令を変更しました！';
$_['error_order'] = '警告注文が見つかりませんでした！';
$_['error_customer'] = 'ご注意お客様情報の入力が必要です！';
$_['error_payment_address'] = 'ご注意支払い先が必要です！';
$_['error_payment_method'] = 'ご注意お支払い方法が必要です！';
$_['error_no_payment'] = 'ご注意お支払い方法はお選びいただけません！';
$_['error_shipping_address'] = 'ご注意配送先が必要です！';
$_['error_shipping_method'] = 'ご注意配送方法が必要です！';
$_['error_no_shipping'] = 'ご注意配送オプションはご利用いただけません！';
$_['error_stock'] = 'ご注意がついている商品は、ご希望の数量がない、または在庫がない商品です！';
$_['error_minimum'] = '警告sの最小注文額は%sです！';
$_['error_product'] = 'ご注意製品が必要です！';
$_['error_comment'] = '警告コメントが必要です！';
?>
