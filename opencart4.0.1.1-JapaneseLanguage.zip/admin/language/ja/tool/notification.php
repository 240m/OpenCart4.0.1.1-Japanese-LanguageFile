<?php
$_['heading_title'] = 'お知らせ';
$_['text_success'] = '成功しました：notificationを変更しました！';
$_['text_list'] = 'お知らせ一覧';
$_['column_message'] = 'メッセージ';
$_['column_action'] = 'アクション';
$_['error_permission'] = '警告あなたには、通知を変更する権限がありません！';
?>
