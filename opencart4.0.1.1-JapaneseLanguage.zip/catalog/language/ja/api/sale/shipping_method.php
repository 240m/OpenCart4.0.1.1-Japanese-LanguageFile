<?php
$_['text_success'] = '成功しました：配送方法が設定されました！';
$_['error_shipping_address'] = 'ご注意配送先が必要です！';
$_['error_shipping_method'] = 'ご注意配送方法が必要です！';
$_['error_no_shipping'] = 'ご注意配送オプションはご利用いただけません！';
$_['error_shipping'] = 'ご注意送料がかかる商品はございません';
?>
