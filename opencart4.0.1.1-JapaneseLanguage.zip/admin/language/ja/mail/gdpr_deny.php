<?php
$_['text_subject'] = 's - GDPR リクエストが拒否されました！';
$_['text_export'] = 'アカウントエクスポートデータリクエスト';
$_['text_remove'] = 'アカウント削除のお願い';
$_['text_hello'] = 'こんにちは<strong>%s</strong>です、';
$_['text_user'] = 'ユーザー';
$_['text_contact'] = '残念ながら、お客様のリクエストは拒否されました。詳細については、こちらの店舗にお問い合わせください：';
$_['text_thanks'] = 'ありがとうございます、';
$_['button_contact'] = 'お問い合わせ';
?>
