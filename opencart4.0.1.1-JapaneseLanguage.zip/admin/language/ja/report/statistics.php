<?php
$_['heading_title'] = '統計情報';
$_['text_success'] = '成功です：あなたは統計学を修正した！';
$_['text_list'] = '統計情報一覧';
$_['text_order_sale'] = '受注販売';
$_['text_order_processing'] = '受注処理';
$_['text_order_complete'] = '終了しました';
$_['text_order_other'] = '受注状況 その他';
$_['text_returns'] = 'リターンズ';
$_['text_customer'] = '承認待ちのお客さま';
$_['text_affiliate'] = '承認待ちのアフィリエイト';
$_['text_product'] = '在庫切れの商品';
$_['text_review'] = '保留中のレビュー';
$_['column_name'] = '統計名';
$_['column_value'] = '価値観';
$_['column_action'] = 'アクション';
$_['error_permission'] = '警告あなたは統計情報を変更する権限を持っていません！';
?>
