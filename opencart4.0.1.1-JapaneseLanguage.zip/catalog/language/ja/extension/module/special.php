<?php
// Heading
$_['heading_title']  = 'スペシャルプライス';

// Text
$_['text_tax']      = '税別:';
