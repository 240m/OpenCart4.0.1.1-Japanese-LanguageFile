<?php
//made by bestshop24h,support email:support@bestshop24h.com  or 95672639@qq.com
// Heading
$_['heading_title']  = 'ページがみつかりません!';

// Text
$_['text_not_found'] = 'あなたが探しているページは見つかりませんでした!。問題が解決しない場合は、システム管理者に連絡してください。';
