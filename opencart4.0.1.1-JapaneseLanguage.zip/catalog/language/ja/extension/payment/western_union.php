<?php
// Text
$_['text_title']       = 'Western Union';
$_['text_instruction'] = 'Western Union Instructions';
$_['text_description'] = 'Please transfer the total amount to the following Western Union account.';
$_['text_payment']     = 'Your order will not ship until we receive payment.';