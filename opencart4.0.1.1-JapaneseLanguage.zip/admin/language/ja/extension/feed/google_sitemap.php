<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = '成功: Google Sitemapを更新しました!';
$_['text_edit']        = 'Google Sitemapの編集';


// Entry
$_['entry_status']     = 'ステータス';
$_['entry_data_feed']  = 'データフィードのURL';


// Error
$_['error_permission'] = '警告: Google Sitemapを更新する権限がありません!';
