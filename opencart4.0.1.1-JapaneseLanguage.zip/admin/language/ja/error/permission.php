<?php
// Heading
$_['heading_title']   = '権限がありません!';

// Text
$_['text_permission'] = 'このページにアクセスする権限がありません。問題がある場合はシステム管理者に連絡してください。';
