<?php
// Text
$_['text_title']  = '重量別送料';
$_['text_weight'] = '重さ:';
