<?php
// Text
$_['text_success']     = 'ショッピングカートを更新しました!';

// Error
$_['error_permission'] = '警告: APIを更新する権限がありません!';
$_['error_stock']      = '*** の印のある商品は在庫が不足しております。数量を変更してください!';
$_['error_minimum']    = ' %s の最少ご注文数は %sです!';
$_['error_store']      = '選択したストアから購入することができない商品です!';
$_['error_required']   = '%s を入力してください!';
