<?php
// Text
$_['text_title']       = '銀行振込';
$_['text_instruction'] = '下記の銀行口座に合計金額をお振込みください。';
$_['text_description'] = '';
$_['text_payment']     = 'ご注文の商品はお振込み確認後の発送となります。';
