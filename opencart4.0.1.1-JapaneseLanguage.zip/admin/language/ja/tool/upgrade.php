<?php
$_['heading_title'] = 'アップグレード';
$_['text_success'] = '成功しました：最新バージョン %s を使用しています！';
$_['text_upgrade'] = '最新バージョンの確認';
$_['text_information'] = 'バージョン情報';
$_['text_current_version'] = '現在のバージョン';
$_['text_latest_version'] = '最新版';
$_['text_date_added'] = '発売日';
$_['text_change'] = '変更履歴';
$_['text_status'] = 'アップグレードステータス';
$_['text_ready'] = 'アップグレードボタンをクリックすると、最新バージョンにアップグレードされます...';
$_['text_download'] = '最新のダウンロード...';
$_['text_install'] = 'ファイルをコピーする...';
$_['text_patch'] = 'パッチを適用する...';
$_['button_upgrade'] = 'アップグレード';
$_['error_permission'] = '警告あなたには、アップグレードを変更する権限がありません！';
$_['error_connection'] = 'アップグレードサーバーに接続できませんでした！';
$_['error_version'] = 'バージョンは現在のバージョンより低いです！';
$_['error_download'] = 'アップグレードのダウンロードができませんでした！';
$_['error_file'] = 'アップグレードファイルが見つかりませんでした！';
$_['error_directory'] = 'ディレクトリ %s を作成できませんでした！';
$_['error_copy'] = 'ファイル %s を %s にコピーできませんでした！';
$_['error_unzip'] = 'Zip ファイルを開くことができませんでした！';
?>
