<?php
$_['heading_title'] = 'あなたのリワードポイント';
$_['column_date_added'] = '追加された日付';
$_['column_description'] = '商品説明';
$_['column_points'] = 'ポイント';
$_['text_account'] = 'アカウント';
$_['text_reward'] = 'リワードポイント';
$_['text_total'] = 'あなたのリワードポイントの総数が';
$_['text_no_results'] = 'リワードポイントをお持ちでない方！';
?>
