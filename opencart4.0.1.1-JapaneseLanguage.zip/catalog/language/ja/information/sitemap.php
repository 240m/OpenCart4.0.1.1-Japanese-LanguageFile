<?php
$_['heading_title'] = 'サイトマップ';
$_['text_special'] = 'スペシャルオファー';
$_['text_account'] = 'マイアカウント';
$_['text_edit'] = 'アカウント情報';
$_['text_password'] = 'パスワード';
$_['text_address'] = 'アドレス帳';
$_['text_history'] = '注文履歴';
$_['text_download'] = 'ダウンロード';
$_['text_cart'] = 'ショッピングカート';
$_['text_checkout'] = 'チェックアウト';
$_['text_search'] = '検索';
$_['text_information'] = 'インフォメーション';
$_['text_contact'] = 'お問い合わせ';
?>
