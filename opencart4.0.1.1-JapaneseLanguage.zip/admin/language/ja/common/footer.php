<?php
// Text
$_['text_footer']  = '<a href="http://www.bestshop24h.com">bestshop24h</a> &copy; 2009-' . date('Y') . ' Japanese .';
$_['text_version'] = 'Version %s';
