<?php
// Heading
$_['heading_title'] = 'おすすめ商品';

// Text
$_['text_tax']      = '税別:';
