<?php
$_['text_wishlist'] = 'ウィッシュリスト (%s)';
$_['text_shopping_cart'] = 'ショッピングカート';
$_['text_account'] = 'マイアカウント';
$_['text_register'] = '登録';
$_['text_login'] = 'ログイン';
$_['text_order'] = '注文履歴';
$_['text_transaction'] = 'トランザクション';
$_['text_download'] = 'ダウンロード';
$_['text_logout'] = 'ログアウト';
$_['text_checkout'] = 'チェックアウト';
?>
