<?php
$_['text_items'] = '%s item(s) - %s';
$_['text_subscription'] = 'サブスクリプション';
$_['text_subscription_trial'] = '%s 毎 %d %s(s)に %d 回の支払をする。';
$_['text_subscription_duration'] = '%s %d %s(s)ごとに %d 回の支払いを行う。';
$_['text_subscription_cancel'] = 'キャンセルされるまで %d %s(s)ごとに %s';
$_['text_day'] = '日';
$_['text_week'] = '週';
$_['text_semi_month'] = '半月';
$_['text_month'] = '月';
$_['text_year'] = 'イヤー';
$_['text_no_results'] = 'ショッピングカートは空っぽです！';
$_['text_cart'] = 'カートを見る';
$_['text_checkout'] = 'チェックアウト';
?>
