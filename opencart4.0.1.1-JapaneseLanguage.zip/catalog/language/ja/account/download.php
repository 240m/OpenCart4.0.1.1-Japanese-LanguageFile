<?php
$_['heading_title'] = 'ダウンロード';
$_['text_account'] = 'アカウント';
$_['text_downloads'] = 'ダウンロード';
$_['text_no_results'] = '過去にダウンロード注文をしたことがない方！';
$_['column_order_id'] = '注文ID';
$_['column_name'] = '名称';
$_['column_size'] = 'サイズ';
$_['column_date_added'] = '追加された日付';
$_['error_not_found'] = 'エラーです：ファイル %s を見つけられませんでした！';
$_['error_headers_sent'] = 'エラーになりました：ヘッダーはすでに送信されています！';
?>
