<?php
$_['heading_title'] = 'パスワードの変更';
$_['text_account'] = 'アカウント';
$_['text_password'] = 'パスワード';
$_['text_success'] = '成功しました：パスワードは正常に更新されました。';
$_['entry_password'] = 'パスワード';
$_['entry_confirm'] = 'パスワードの確認';
$_['error_token'] = '警告パスワードトークンが無効です！';
$_['error_password'] = 'パスワードは、4文字以上20文字以下で設定してください！';
$_['error_confirm'] = 'パスワードの確認がパスワードと一致しない！';
?>
