<?php
$_['heading_title'] = 'Cronの仕事';
$_['text_success'] = '成功しました：cronジョブを変更しました！';
$_['text_instruction'] = 'CRONの説明';
$_['text_list'] = 'クロンリスト';
$_['text_cron_1'] = 'クーロンジョブは、定期的に実行されるスケジュールタスクです。クーロンジョブを使用するようにサーバーを設定するには、<a href="http://docs.opencart.com/extension/cron/" target="_blank" class="alert-link">opencartdocumentation</a> ページをお読みください。';
$_['text_cron_2'] = 'Cronタスクが1時間ごとに実行されるように設定する必要があります。';
$_['text_info'] = 'CRON情報';
$_['text_hour'] = '時間';
$_['text_day'] = '日';
$_['text_month'] = '月';
$_['column_code'] = 'クロンコード';
$_['column_cycle'] = 'サイクル';
$_['column_date_added'] = '追加された日付';
$_['column_date_modified'] = '修正日';
$_['column_action'] = 'アクション';
$_['entry_cron'] = 'クロンURL';
$_['entry_description'] = '商品説明';
$_['error_permission'] = '警告あなたには、cronジョブを変更する権限がありません！';
?>
