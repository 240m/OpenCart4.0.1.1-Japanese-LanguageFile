<?php
// Heading
$_['heading_title']    = 'インフォメーション';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']        = '成功: インフォメーションを更新しました!';
$_['text_edit']           = 'インフォメーションの編集';


// Entry
$_['entry_status']     = 'ステータス';

// Error
$_['error_permission']    = '警告: インフォメーションを更新する権限がありません!';
