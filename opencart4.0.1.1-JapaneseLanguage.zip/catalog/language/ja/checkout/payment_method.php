<?php
$_['heading_title'] = 'お支払い方法';
$_['text_stored'] = '支払い方法の保存';
$_['text_comments'] = '注文に関するコメントを追加する';
$_['text_agree'] = '<a href="%s" class="modal-link"><b>%s</b></a> を読み、これに同意します。';
$_['text_success'] = '成功しました：支払い方法を変更しました！';
$_['text_comment'] = '成功です：コメントが追加されました！';
$_['error_payment_address'] = 'ご注意支払い先が必要です！';
$_['error_payment_method'] = 'ご注意お支払い方法が必要です！';
$_['error_no_payment'] = 'ご注意お支払い方法が選択できません。<a href="%s">お問い合わせ</a>をお願いします！';
?>
