<?php
//made by bestshop24h,support email:support@bestshop24h.com  or 95672639@qq.com
// Heading
$_['heading_title']          = '属性管理';

// Text
$_['text_success']           = '成功: 属性を更新しました!';
$_['text_list']              = '属性リスト';
$_['text_add']               = '属性の追加';
$_['text_edit']              = '属性の編集';

// Column
$_['column_name']            = '属性名';
$_['column_attribute_group'] = '属性グループ';
$_['column_sort_order']      = '表示順';
$_['column_action']          = '処理';

// Entry
$_['entry_name']             = '属性名';
$_['entry_attribute_group']  = '属性グループ';
$_['entry_sort_order']       = '表示順';

// Error
$_['error_permission']       = '警告:属性を更新する権限がありません!';
$_['error_name']             = '属性名は3文字以上64文字以下で入力してください!';
$_['error_product']          = '警告: この属性は、現在 %s 点の商品に使用されているため、削除できません!';

$_['error_attribute_group']  = '属性グループは必要です!';
