<?php
$_['text_category'] = 'カテゴリー';
$_['text_all'] = 'すべて表示';
?>
