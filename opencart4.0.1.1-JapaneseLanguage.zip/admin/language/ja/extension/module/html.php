<?php
// Heading
$_['heading_title']     = 'HTMLコンテンツ';

// Text
$_['text_extension']    = 'Extensions';
$_['text_success']        = '成功: HTMLコンテンツを更新しました!';
$_['text_edit']           = 'HTMLコンテンツの編集';

// Entry
$_['entry_name']        = 'モジュール名';
$_['entry_title']       = 'タイトル';
$_['entry_description']   = 'コンテンツ';
$_['entry_status']        = 'ステータス';

// Error
$_['error_permission']    = '警告:HTMLコンテンツを更新する権限がありません!';
$_['error_name']        = 'Module Name must be between 3 and 64 characters!';
