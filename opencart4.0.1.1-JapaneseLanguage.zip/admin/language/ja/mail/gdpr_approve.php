<?php
$_['text_subject'] = 's - GDPR リクエストが承認されました！';
$_['text_request'] = 'アカウント削除のお願い';
$_['text_hello'] = 'こんにちは<strong>%s</strong>です、';
$_['text_user'] = 'ユーザー';
$_['text_gdpr'] = 'お客様のGDPRデータ削除リクエストは承認され、<strong>%s Days</strong>で削除される予定です。';
$_['text_q'] = 'Q.なぜ、お客様のデータをそのまま削除しないのですか？';
$_['text_a'] = 'A.アカウント削除のリクエストは、<strong>%s days</strong>の後に処理されるため、返金、チャージバック、詐欺の検出が処理されます。';
$_['text_delete'] = 'アカウントが削除されると、その旨を知らせるメールが届きます。';
$_['text_thanks'] = 'ありがとうございます、';
?>
