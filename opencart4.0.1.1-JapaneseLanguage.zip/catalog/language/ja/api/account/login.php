<?php
$_['text_success'] = '成功しました：APIセッションが正常に開始されました！';
$_['error_permission'] = '警告APIにアクセスする権限がありません！';
$_['error_key'] = '警告APIキーが正しくありません！';
$_['error_ip'] = '警告あなたのIP %s はこのAPIへのアクセスを許可されていません！';
?>
