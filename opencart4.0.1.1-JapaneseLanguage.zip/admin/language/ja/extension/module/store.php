<?php
// Heading
$_['heading_title']    = 'ストア';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']        = '成功: ストアを更新しました!';
$_['text_edit']           = 'ストアの編集';


// Entry
$_['entry_admin']      = '管理者のみ';
$_['entry_status']     = 'ステータス';

// Error
$_['error_permission']    = '警告:ストアを更新する権限がありません!';
