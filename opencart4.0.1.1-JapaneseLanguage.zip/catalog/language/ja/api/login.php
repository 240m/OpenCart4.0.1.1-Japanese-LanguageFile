<?php
// Text
$_['text_success'] = '成功:APIセッションを開始しました!';

// Error
$_['error_key']    = '警告：不正なAPIキー！';
$_['error_ip']     = '警告：あなたのIP％sはこのAPIにアクセスできません！';