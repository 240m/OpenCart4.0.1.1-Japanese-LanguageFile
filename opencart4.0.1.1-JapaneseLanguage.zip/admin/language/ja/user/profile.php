<?php
$_['heading_title'] = 'プロフィール';
$_['text_success'] = '成功しました：プロフィールを変更しました！';
$_['text_edit'] = 'プロフィールを編集する';
$_['text_user'] = 'ユーザー詳細';
$_['text_password'] = 'パスワード';
$_['entry_username'] = 'ユーザー名';
$_['entry_password'] = 'パスワード';
$_['entry_confirm'] = '確認';
$_['entry_firstname'] = 'ファーストネーム';
$_['entry_lastname'] = 'ラストネーム';
$_['entry_email'] = '電子メール';
$_['entry_image'] = 'イメージ';
$_['error_permission'] = '警告あなたは自分のプロフィールを変更する権限を持っていません！';
$_['error_username_exists'] = '警告ユーザー名はすでに使用されています！';
$_['error_username'] = 'ユーザー名は、3文字以上20文字以下で入力してください！';
$_['error_password'] = 'パスワードは、4文字以上20文字以下で設定してください！';
$_['error_confirm'] = 'パスワードとパスワード確認が一致しない！';
$_['error_firstname'] = 'ファーストネームは、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = 'Last Nameは1文字以上32文字以内で入力してください！';
$_['error_email'] = 'E-Mailアドレスが有効でないようです！';
$_['error_email_exists'] = '警告E-Mailアドレスはすでに登録されています！';
?>
