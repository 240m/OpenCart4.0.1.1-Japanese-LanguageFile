<?php
$_['heading_title'] = 'マイウィッシュリスト';
$_['text_account'] = 'アカウント';
$_['text_instock'] = '在庫あり';
$_['text_wishlist'] = 'ウィッシュリスト (%s)';
$_['text_login'] = '<a href="%s">%s</a>を<a href="%s">ウィッシュリスト</a>に保存するには、<a href="%s">ログイン</a>または<a href="%s">アカウントを作成</a>する必要があります！';
$_['text_success'] = '成功しました：<a href="%s">%s</a>を<a href="%s">ウィッシュリスト</a>に追加しました！';
$_['text_remove'] = '成功しました：ウィッシュリストに登録されている商品を削除しました';
$_['text_no_results'] = 'あなたのウィッシュリストは空っぽです。';
$_['column_image'] = 'イメージ';
$_['column_name'] = '製品名';
$_['column_model'] = 'モデル';
$_['column_stock'] = '在庫';
$_['column_price'] = '単価';
$_['column_action'] = 'アクション';
$_['error_product'] = '警告製品が見つかりませんでした！';
?>
