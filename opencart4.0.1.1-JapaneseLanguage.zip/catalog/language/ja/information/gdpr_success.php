<?php
$_['heading_title'] = 'GDPRの成功';
$_['text_account'] = 'アカウント';
$_['text_export'] = 'お客様のアカウントデータのエクスポートのリクエストを受け取りました。';
$_['text_remove'] = 'GDPRアカウント削除リクエストは、<strong>%s days</strong>後に処理されるため、チャージバック、返金、詐欺の検出を処理することができます。';
?>
