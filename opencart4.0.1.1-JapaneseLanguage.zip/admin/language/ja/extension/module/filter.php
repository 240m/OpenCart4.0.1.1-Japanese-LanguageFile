<?php
// Heading
$_['heading_title']    = 'フィルター';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']        = '成功: フィルターを更新しました!';
$_['text_edit']           = 'フィルターの編集';

// Entry
$_['entry_status']     = 'ステータス';

// Error
$_['error_permission']    = '警告:フィルターを更新する権限がありません!';
