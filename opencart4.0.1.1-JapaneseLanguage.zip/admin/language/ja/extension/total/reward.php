<?php
// Heading
$_['heading_title']    = 'ポイント';

// Text
$_['text_extension']       = '拡張機能';
$_['text_success']     = '成功: ポイントを更新しました!';
$_['text_edit']        = 'ポイントの編集';

// Entry
$_['entry_status']     = 'ステータス';
$_['entry_sort_order'] = '表示順';

// Error
$_['error_permission'] = '警告: ポイントを更新する権限がありません!';
