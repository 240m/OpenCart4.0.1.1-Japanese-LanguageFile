<?php
$_['heading_title'] = '発送方法';
$_['text_success'] = '成功しました：配送方法を変更しました！';
$_['error_shipping_address'] = 'ご注意配送先が必要です！';
$_['error_shipping_method'] = 'ご注意配送方法が必要です！';
$_['error_no_shipping'] = 'ご注意配送オプションはご利用いただけません。<a href="%s">お問い合わせ</a>をお願いします！';
?>
