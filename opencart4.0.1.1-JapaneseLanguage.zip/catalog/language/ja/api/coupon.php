<?php
//made by bestshop24h,support email:support@bestshop24h.com  or 95672639@qq.com
// Text
$_['text_success']     = 'クーポンが適用されました!';

// Error
$_['error_permission'] = '警告: APIを更新する権限がありません!';
$_['error_coupon']     = '警告: クーポンは無効、有効期限切れ、または使用限度に達しています!';
