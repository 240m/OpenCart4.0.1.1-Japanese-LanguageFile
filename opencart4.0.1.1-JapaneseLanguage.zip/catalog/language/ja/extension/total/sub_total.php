<?php
// Text
$_['text_sub_total'] = '小計';
