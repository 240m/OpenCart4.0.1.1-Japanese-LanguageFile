<?php
$_['heading_title'] = 'パスワードをお忘れの方';
$_['heading_reset'] = 'パスワードの再設定';
$_['text_account'] = 'アカウント';
$_['text_forgotten'] = 'パスワードを忘れた場合';
$_['text_your_email'] = 'お客様のEメールアドレス';
$_['text_email'] = 'アカウントに関連付けられた電子メールアドレスを入力します。送信をクリックすると、パスワードリセットリンクがメールで送信されます。';
$_['text_password'] = '使用する新しいパスワードを入力します。';
$_['text_success'] = '成功しました：パスワードは正常に更新されました。';
$_['entry_email'] = 'E-mailアドレス';
$_['entry_new_password'] = '新しいパスワード';
$_['entry_password'] = 'パスワード';
$_['entry_confirm'] = '確認';
$_['error_email'] = 'E-Mailアドレスが有効でないようです！';
$_['error_not_found'] = '警告E-Mailアドレスが当社の記録で見つかりませんでした！';
$_['error_password'] = 'パスワードは、4文字以上20文字以下で設定してください！';
$_['error_confirm'] = 'パスワードとパスワード確認が一致しない！';
$_['error_code'] = 'パスワードリセットコードが無効、または過去に使用されたものである！';
?>
