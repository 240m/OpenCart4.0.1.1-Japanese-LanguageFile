<?php
// Text
$_['text_title']	= 'PayPal';
$_['text_testmode']				= 'Warning: Sandbox Modeモードです。口座に金額は振り込まれません。';
$_['text_total']				= '送料, 手数料, 割引 & 税金';