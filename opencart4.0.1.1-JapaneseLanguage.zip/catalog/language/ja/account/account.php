<?php
$_['heading_title'] = 'マイアカウント';
$_['text_account'] = 'アカウント';
$_['text_my_account'] = 'マイアカウント';
$_['text_my_orders'] = 'マイオーダー';
$_['text_my_affiliate'] = 'マイ・アフィリエイト・アカウント';
$_['text_my_newsletter'] = 'ニュースレター';
$_['text_edit'] = 'アカウント情報を編集する';
$_['text_password'] = 'パスワードを変更する';
$_['text_address'] = 'アドレス帳の項目を修正する';
$_['text_payment_method'] = 'お支払い方法について';
$_['text_wishlist'] = 'ウィッシュリストを修正する';
$_['text_order'] = '注文履歴を見る';
$_['text_subscription'] = 'サブスクリプション';
$_['text_download'] = 'ダウンロード';
$_['text_reward'] = 'あなたのリワードポイント';
$_['text_return'] = '返品依頼を見る';
$_['text_transaction'] = 'お客様のお取引について';
$_['text_newsletter'] = 'ニュースレターの登録・解除';
$_['text_transactions'] = 'トランザクション';
$_['text_affiliate_add'] = 'アフィリエイトアカウントを登録する';
$_['text_affiliate_edit'] = 'アフィリエイト情報を編集する';
$_['text_tracking'] = 'カスタムアフィリエイトのトラッキングコード';
?>
