<?php
$_['heading_title'] = 'オンラインレポート';
$_['text_extension'] = 'エクステンション';
$_['text_success'] = '成功しました：お客様のオンラインレポートを変更しました！';
$_['text_list'] = 'オンラインリスト';
$_['text_filter'] = 'フィルター';
$_['text_guest'] = 'ゲスト';
$_['column_ip'] = 'IP';
$_['column_customer'] = 'お客様';
$_['column_url'] = '最後に閲覧したページ';
$_['column_referer'] = 'リファラー';
$_['column_date_added'] = '最後のクリック';
$_['column_action'] = 'アクション';
$_['entry_ip'] = 'IP';
$_['entry_customer'] = 'お客様';
$_['error_permission'] = '警告お客様には、オンラインレポートを変更する権限がありません！';
?>
