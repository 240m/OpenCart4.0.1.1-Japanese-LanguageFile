<?php
// Text
$_['text_title'] = '代金引換';
