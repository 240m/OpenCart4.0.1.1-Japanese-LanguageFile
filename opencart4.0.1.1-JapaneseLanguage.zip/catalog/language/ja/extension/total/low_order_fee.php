<?php
// Text
$_['text_low_order_fee'] = '低額注文手数料';
