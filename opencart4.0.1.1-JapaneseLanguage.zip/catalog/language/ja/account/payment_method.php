<?php
$_['heading_title'] = 'お支払い方法について';
$_['text_account'] = 'アカウント';
$_['text_payment_method'] = '支払い方法の入力';
$_['text_success'] = 'お支払い方法が正常に削除されました';
$_['text_no_results'] = 'お客様のアカウントに支払い方法がありません。';
$_['column_payment_method'] = 'お支払い方法';
$_['column_type'] = 'タイプ';
$_['column_date_expire'] = '日付 有効期限';
$_['column_action'] = 'アクション';
$_['error_payment_method'] = '警告支払い方法が見つかりませんでした！';
?>
