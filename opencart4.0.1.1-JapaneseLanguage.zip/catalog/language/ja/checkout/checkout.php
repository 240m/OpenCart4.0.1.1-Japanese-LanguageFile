<?php
$_['heading_title'] = 'チェックアウト';
$_['text_cart'] = 'ショッピングカート';
?>
