<?php
//made by bestshop24h,support email:support@bestshop24h.com  or 95672639@qq.com
// header
$_['heading_title']  = 'ユーザーログイン';

// Text
$_['text_heading']   = '管理画面';
$_['text_login']     = 'ログインの詳細を入力してください。';
$_['text_forgotten'] = 'パスワードを忘れた';

// Entry
$_['entry_username'] = 'ログインID:';
$_['entry_password'] = 'パスワード:';

// Button
$_['button_login']   = 'ログイン';

// Error
$_['error_login']    = 'ユーザー名またはパスワードが違います!';
$_['error_token']    = '無効なトークンセッションです。もう一度ログインしてください';
