<?php
// Heading
$_['heading_title'] = 'ストアを選択';

// Text
$_['text_default']  = 'デフォルト';
$_['text_store']    = 'ご覧になりたいストアを選択してください。';
