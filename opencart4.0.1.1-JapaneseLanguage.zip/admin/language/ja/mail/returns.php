<?php
$_['text_subject'] = 's - リターン・アップデート %s';
$_['text_return_id'] = 'リターンIDです：';
$_['text_date_added'] = '返却日です：';
$_['text_return_status'] = 'あなたのリターンは、以下のステータスに更新されました：';
$_['text_comment'] = 'お帰りの際のコメントです：';
$_['text_footer'] = 'ご不明な点がございましたら、このメールにご返信ください。';
?>
