<?php
$_['heading_title'] = 'バックアップ＆リストア';
$_['text_success'] = '成功です：データベースの変更に成功しました！';
$_['text_backup'] = 'テーブル %s レコード %s を %s レコードにバックアップしています。';
$_['text_restore'] = 'の %s をリストアする。';
$_['text_option'] = 'バックアップオプション';
$_['text_history'] = 'バックアップの歴史';
$_['text_progress'] = '進捗状況';
$_['text_import'] = '大きなバックアップファイルの場合、SQLファイルをFTPで<strong>~/storage/backup/</strong>ディレクトリにアップロードするのがよいでしょう。';
$_['column_filename'] = 'ファイル名';
$_['column_size'] = 'サイズ';
$_['column_date_added'] = '追加された日付';
$_['column_action'] = 'アクション';
$_['entry_progress'] = '進捗状況';
$_['entry_export'] = '出力';
$_['error_permission'] = '警告あなたには、Backup &amp; Restoreを変更する権限がありません！';
$_['error_export'] = '警告エクスポートするテーブルを少なくとも1つ選択する必要があります！';
$_['error_table'] = 'テーブル %s は許可リストにありません！';
$_['error_file'] = 'ファイルが見つかりませんでした！';
$_['error_directory'] = 'ディレクトリが見つかりませんでした！';
$_['error_not_found'] = 'エラーです：ファイル %s を見つけられませんでした！';
$_['error_headers_sent'] = 'エラーになりました：ヘッダーはすでに送信されています！';
$_['error_upload_size'] = 'アップロードファイルは%sより大きくすることはできません！';
?>
