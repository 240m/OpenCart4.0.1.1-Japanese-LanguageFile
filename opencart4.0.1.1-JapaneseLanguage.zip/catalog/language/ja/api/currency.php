<?php
// Text
$_['text_success']     = '成功：あなたの通貨は変更されました！';

// Error
$_['error_permission'] = '警告：APIにアクセスする権限がありません。';
$_['error_currency']   = '警告：通貨コードが無効です！';