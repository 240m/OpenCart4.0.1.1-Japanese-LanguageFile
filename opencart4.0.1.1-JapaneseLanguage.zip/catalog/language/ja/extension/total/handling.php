<?php
// Text
$_['text_handling'] = '取扱手数料';
