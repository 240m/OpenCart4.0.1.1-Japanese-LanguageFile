<?php
$_['error_language'] = '警告言語が見つかりませんでした！';
?>
