<?php
// Text
$_['text_total'] = '合計';
