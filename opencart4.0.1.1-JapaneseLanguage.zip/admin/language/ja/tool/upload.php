<?php
$_['heading_title'] = 'アップロード';
$_['text_success'] = '成功しました：アップロードを修正しました！';
$_['text_list'] = 'アップロードリスト';
$_['text_filter'] = 'フィルター';
$_['column_name'] = 'アップロード名';
$_['column_code'] = 'コード';
$_['column_date_added'] = '追加された日付';
$_['column_action'] = 'アクション';
$_['entry_name'] = 'アップロード名';
$_['entry_filename'] = 'ファイル名';
$_['entry_date_from'] = '日付 From';
$_['entry_date_to'] = '日付 To';
$_['error_permission'] = '警告あなたはアップロードを変更する権限を持っていません！';
$_['error_not_found'] = 'エラーです：ファイル %s を見つけられませんでした！';
$_['error_headers_sent'] = 'エラーになりました：ヘッダーはすでに送信されています！';
$_['error_upload'] = 'ファイルをアップロードすることができませんでした！';
$_['error_filename'] = 'ファイル名は、3文字以上128文字以下で入力してください！';
$_['error_file_type'] = '無効なファイルタイプです！';
?>
