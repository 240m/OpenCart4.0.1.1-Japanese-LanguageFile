<?php
$_['heading_title'] = 'アドレス形式';
$_['text_success'] = '成功しました：アドレスフォーマットを変更しました！';
$_['text_list'] = 'アドレスフォーマット一覧';
$_['text_add'] = 'アドレス形式を追加';
$_['text_edit'] = 'アドレス形式を編集する';
$_['column_name'] = 'アドレスフォーマット名';
$_['column_address_format'] = 'アドレス形式';
$_['column_action'] = 'アクション';
$_['entry_name'] = 'アドレスフォーマット名';
$_['entry_address_format'] = 'アドレス形式';
$_['help_address_format'] = '姓 = {firstname}<br/> 名 = {lastname}<br/> 会社 = {company}<br/> 住所1 = {address_1}<br/> 住所2 = {address_2}<br/> 都市 = {city}<br/> 郵便番号 = {postcode}<br/> 帯 = {zone}<br/> 帯コード = {zone_code}<br/> 国 = {country}';
$_['error_permission'] = '警告あなたはアドレスフォーマットを変更する権限を持っていません！';
$_['error_name'] = 'アドレス形式 名は1文字以上128文字以下で入力してください！';
$_['error_default'] = '警告このアドレス形式は、現在デフォルトのアドレス形式として割り当てられているため、削除することはできません！';
$_['error_country'] = '警告このアドレス形式は、現在 %s の国に割り当てられているため、削除することはできません！';
?>
