<?php
// Text
$_['text_subject']  = '%s - 報酬ポイント';
$_['text_received'] = 'あなたは %sリワードポイントを受け取りました！ ';
$_['text_total']    = '報酬ポイントの総数は今 %s　です.';