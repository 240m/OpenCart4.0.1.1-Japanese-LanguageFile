<?php 
// Text made by bestshop24h.com
$_['text_success']       = '顧客情報を更新しました';

// Error
$_['error_permission']   = '警告: APIを更新する権限がありません!';
$_['error_customer']     = 'お客様を選択する必要があります！';
$_['error_firstname']    = '氏名(姓)は1文字以上32文字以下で入力してください!';
$_['error_lastname']     = '氏名(名)は1文字以上32文字以下で入力してください!';
$_['error_email']        = 'メールアドレスは無効です!';
$_['error_telephone']    = '電話番号は3文字以上32文字以下で入力してください!';
$_['error_custom_field'] = '%s を入力してください!';
