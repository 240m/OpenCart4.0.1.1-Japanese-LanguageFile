<?php
$_['text_information'] = 'インフォメーション';
$_['text_service'] = 'カスタマー・サービス';
$_['text_extra'] = 'エクストラ';
$_['text_contact'] = 'お問い合わせ';
$_['text_return'] = 'リターンズ';
$_['text_sitemap'] = 'サイトマップ';
$_['text_gdpr'] = 'GDPR';
$_['text_manufacturer'] = 'ブランド';
$_['text_voucher'] = 'ギフト券';
$_['text_affiliate'] = 'アフィリエイト';
$_['text_special'] = '特別企画';
$_['text_account'] = 'マイアカウント';
$_['text_order'] = '注文履歴';
$_['text_wishlist'] = 'ウィッシュリスト';
$_['text_newsletter'] = 'ニュースレター';
$_['text_powered'] = 'Powered By <a href="https://www.opencart.com">OpenCart</a><br/> %s &copy; %s';
?>
