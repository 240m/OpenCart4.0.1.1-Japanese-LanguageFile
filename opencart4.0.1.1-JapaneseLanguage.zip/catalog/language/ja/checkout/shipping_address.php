<?php
$_['heading_title'] = '配送先住所';
$_['text_address_new'] = '新しいアドレスを使いたい';
$_['text_address_existing'] = '既存のアドレスを利用したい';
$_['text_success'] = '成功しました：配送先住所を変更しました！';
$_['entry_address'] = 'アドレスの選択';
$_['entry_firstname'] = 'ファーストネーム';
$_['entry_lastname'] = 'ラストネーム';
$_['entry_company'] = 'カンパニー';
$_['entry_address_1'] = 'アドレス1';
$_['entry_address_2'] = 'アドレス2';
$_['entry_postcode'] = '郵便番号';
$_['entry_city'] = '都市';
$_['entry_country'] = '国名';
$_['entry_zone'] = '地域・州';
$_['error_address'] = '警告配送先が見つかりませんでした！';
$_['error_firstname'] = 'ファーストネームは、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = 'Last Nameは1文字以上32文字以内で入力してください！';
$_['error_address_1'] = 'アドレス1は、3文字以上128文字以下とします！';
$_['error_city'] = 'Cityは2文字以上128文字以下で入力してください！';
$_['error_postcode'] = '郵便番号は2文字以上10文字以下で入力してください！';
$_['error_country'] = '国を選択してください！';
$_['error_zone'] = '地域/州を選択してください！';
$_['error_custom_field'] = 'sが必要です！';
$_['error_regex'] = 'sは有効な入力ではありません！';
?>
