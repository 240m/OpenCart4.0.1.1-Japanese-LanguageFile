<?php
$_['heading_title'] = 'OpenCart マーケットプレイス API';
$_['text_success'] = '成功しました：API情報を変更しました！';
$_['text_signup'] = '<a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link"> こちら</a>から取得できるOpenCart API情報を入力してください。';
$_['entry_username'] = 'ユーザー名';
$_['entry_secret'] = 'シークレット';
$_['error_permission'] = '警告マーケットプレイスAPIを変更する権限がありません！';
$_['error_username'] = 'ユーザー名が必要です！';
$_['error_secret'] = 'シークレットが必要です！';
?>
