<?php
$_['text_success'] = 'ご選択をお知らせいただき、ありがとうございました！';
$_['text_cookie'] = '本サイトでは、Cookieを使用しています。詳しくは<a href="%s" class="alert-link modal-link">click here</a>をご覧ください。';
$_['button_agree'] = 'はい、それで結構です！';
$_['button_disagree'] = 'ノーサンキューです！';
?>
