<?php
$_['heading_title'] = 'アカウントログイン';
$_['text_account'] = 'アカウント';
$_['text_login'] = 'ログイン';
$_['text_new_customer'] = '新規のお客様';
$_['text_register'] = 'アカウント登録';
$_['text_register_account'] = 'アカウントを作成することで、より速く買い物をしたり、注文の状況を把握したり、過去に行った注文を記録したりすることができるようになります。';
$_['text_returning_customer'] = 'リピーターのお客様';
$_['text_i_am_returning_customer'] = '私はリピーターです';
$_['text_forgotten'] = 'パスワードを忘れた場合';
$_['entry_email'] = 'E-mailアドレス';
$_['entry_password'] = 'パスワード';
$_['error_token'] = '警告：ログイントークンが無効です！';
$_['error_login'] = '警告E-Mailアドレスとパスワードに一致するものがありません。';
$_['error_attempts'] = '警告あなたのアカウントは、ログイン試行回数の許容値を超えています。1時間以内に再試行してください。';
$_['error_approved'] = '警告ログインする前に、アカウントの承認が必要です。';
?>
