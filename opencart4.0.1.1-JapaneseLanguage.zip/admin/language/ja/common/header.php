<?php
// Heading
$_['heading_title']      = 'OpenCart　管理画面';

// Text
$_['text_profile']       = 'あなたのプロフィール';
$_['text_store']         = 'ストア';
$_['text_help']          = 'ヘルプ';
$_['text_homepage']      = 'OpenCart ホームページ';
$_['text_support']       = 'サポートフォーラム';
$_['text_documentation'] = 'ドキュメンテーション';
$_['text_logout']        = 'ログアウト';