<?php
// Heading
$_['heading_title']    = 'アカウント';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']        = '成功: アカウントを更新しました!';
$_['text_edit']           = 'アカウントの編集';


// Entry
$_['entry_status']     = 'ステータス';

// Error
$_['error_permission']    = '警告: アカウントを更新する権限がありません!';
