<?php
$_['heading_title'] = 'ニュースレター購読';
$_['text_account'] = 'アカウント';
$_['text_newsletter'] = 'ニュースレター';
$_['text_success'] = '成功しました：ニュースレターの購読が正常に更新されました！';
$_['entry_newsletter'] = 'サブスクライブ';
?>
