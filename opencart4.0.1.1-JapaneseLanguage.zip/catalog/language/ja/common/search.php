<?php
$_['text_search'] = '検索';
?>
