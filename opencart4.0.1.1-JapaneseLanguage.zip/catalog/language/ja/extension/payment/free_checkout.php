<?php
// Text
$_['text_title'] = 'フリーチェックアウト';
