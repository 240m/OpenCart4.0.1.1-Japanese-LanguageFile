<?php
// Text
$_['text_captcha']  = 'キャプチャ';

// Entry
$_['entry_captcha'] = '以下のキャプチャ検証を完了してください';

// Error
$_['error_captcha'] = '確認が正しくありません！';