<?php
$_['text_success'] = 'サクセスあなたの言語が変更されました！';
$_['error_language'] = '警告言語が見つかりませんでした！';
?>
