<?php
$_['heading_title'] = 'お問い合わせ';
$_['text_location'] = '事業所一覧';
$_['text_store'] = '店舗紹介';
$_['text_contact'] = 'お問い合わせフォーム';
$_['text_address'] = 'アドレス';
$_['text_telephone'] = '電話番号';
$_['text_open'] = '開館時間';
$_['text_comment'] = 'コメント';
$_['text_message'] = '<p>お問い合わせはストアオーナーに送信されました</p>。';
$_['entry_name'] = 'あなたのお名前';
$_['entry_email'] = 'E-mailアドレス';
$_['entry_enquiry'] = 'お問い合わせ';
$_['email_subject'] = 'お問い合わせ %s';
$_['error_name'] = '名前は、3文字以上32文字以下で入力してください！';
$_['error_email'] = 'E-Mailアドレスが有効でないようです！';
$_['error_enquiry'] = 'お問い合わせは10文字以上3000文字以内でお願いします！';
?>
