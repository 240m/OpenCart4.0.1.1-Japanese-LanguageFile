<?php
$_['error_extension'] = '警告支払方法拡張が見つかりませんでした！';
$_['error_recurring'] = '警告支払い方法に定期的な支払い方法がありません！';
$_['error_payment'] = '警告支払方法 %s が見つかりませんでした！';
?>
