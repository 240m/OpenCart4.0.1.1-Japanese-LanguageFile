<?php
$_['text_currency'] = '通貨';
?>
