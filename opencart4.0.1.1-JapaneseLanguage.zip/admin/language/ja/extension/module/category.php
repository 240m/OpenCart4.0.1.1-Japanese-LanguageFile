<?php
// Heading
$_['heading_title']    = 'カテゴリー';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']        = '成功: カテゴリーを更新しました!';
$_['text_edit']           = 'カテゴリーの編集';


// Entry
$_['entry_status']     = 'ステータス';

// Error
$_['error_permission']    = '警告:カテゴリーを更新する権限がありません!';
