<?php
// Heading
$_['heading_title'] = 'インフォメーション';

// Text
$_['text_contact']  = 'お問合せ';
$_['text_sitemap']  = 'サイトマップ';
