<?php
$_['text_success'] = 'お客様の修正に成功しました';
$_['error_customer'] = '警告お客様が見つかりませんでした！';
$_['error_customer_group'] = 'カスタマーグループが有効でないようです！';
$_['error_firstname'] = 'ファーストネームは、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = 'Last Nameは1文字以上32文字以内で入力してください！';
$_['error_email'] = 'E-Mailアドレスが有効でないようです！';
$_['error_telephone'] = '電話番号は、3文字以上32文字以下で入力してください！';
$_['error_custom_field'] = 'sが必要です！';
$_['error_regex'] = 'sは有効な入力ではありません！';
?>
