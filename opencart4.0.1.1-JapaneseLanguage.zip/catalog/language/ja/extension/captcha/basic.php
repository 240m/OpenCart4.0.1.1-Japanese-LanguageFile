<?php
// Text
$_['text_captcha']  = 'キャプチャ';

// Entry
$_['entry_captcha'] = '下のボックスにコードを入力してください';

// Error
$_['error_captcha'] = '確認コードが画像と一致しません。';