<?php
// Heading
$_['heading_title'] = 'ダッシュボード';

// Error
$_['error_install']                = '警告: セキュリティ上問題が発生する可能性がありますので、サーバのインストールフォルダ(install)を削除してください!';
