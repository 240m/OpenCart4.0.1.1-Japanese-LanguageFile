<?php
$_['text_subject'] = 's - GDPR エクスポート要求が完了しました！';
$_['text_request'] = '個人情報のエクスポート';
$_['text_hello'] = 'こんにちは<strong>%s</strong>です、';
$_['text_user'] = 'ユーザー';
$_['text_gdpr'] = 'GDPRデータのリクエストは完了しました。以下では、お客様のGDPRデータをご覧いただけます。';
$_['text_account'] = 'アカウント';
$_['text_customer'] = '個人情報';
$_['text_address'] = 'アドレス';
$_['text_addresses'] = 'アドレス';
$_['text_name'] = 'お客様名';
$_['text_recipient'] = '受取人';
$_['text_email'] = '電子メール';
$_['text_telephone'] = '電話番号';
$_['text_company'] = 'カンパニー';
$_['text_address_1'] = 'アドレス1';
$_['text_address_2'] = 'アドレス2';
$_['text_postcode'] = '郵便番号';
$_['text_city'] = '都市';
$_['text_country'] = '国名';
$_['text_zone'] = '地域・州';
$_['text_history'] = 'ログイン履歴';
$_['text_ip'] = 'IP';
$_['text_date_added'] = '追加された日付';
$_['text_thanks'] = 'ありがとうございます、';
?>
