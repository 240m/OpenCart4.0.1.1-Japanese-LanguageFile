<?php
// Text
$_['text_success']     = 'ポイントが適用されました!';

// Error
$_['error_permission'] = 'Warning: APIを更新する権限がありません!';
$_['error_reward']     = 'Warning: 使用するポイント数を入力してください!';
$_['error_points']     = 'Warning: %sのポイントをお持ちではありません!';
$_['error_maximum']    = 'Warning: 使用できるポイント数は最大 %sです!';