<?php
$_['heading_title'] = '支払先住所';
$_['text_address_new'] = '新しいアドレスを使いたい';
$_['text_address_existing'] = '既存のアドレスを利用したい';
$_['text_success'] = '成功しました：支払い先が変更されました！';
$_['entry_address'] = 'アドレスの選択';
$_['entry_firstname'] = '名';
$_['entry_lastname'] = '姓';
$_['entry_company'] = '会社名';
$_['entry_address_1'] = '住所';
$_['entry_address_2'] = '部屋';
$_['entry_postcode'] = '郵便番号';
$_['entry_city'] = '市町村';
$_['entry_country'] = '国名';
$_['entry_zone'] = '都道府県';
$_['error_address'] = '警告支払先が見つかりませんでした！';
$_['error_firstname'] = '名前(名)は、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = '名前(姓)は1文字以上32文字以内で入力してください！';
$_['error_address_1'] = '住所は、3文字以上128文字以下とします！';
$_['error_city'] = '市町村は2文字以上128文字以下で入力してください！';
$_['error_postcode'] = '郵便番号は2文字以上10文字以下で入力してください！';
$_['error_country'] = '国を選択してください！';
$_['error_zone'] = '都道府県を選択してください！';
$_['error_custom_field'] = 'sが必要です！';
$_['error_regex'] = 'sは有効な入力ではありません！';
?>
