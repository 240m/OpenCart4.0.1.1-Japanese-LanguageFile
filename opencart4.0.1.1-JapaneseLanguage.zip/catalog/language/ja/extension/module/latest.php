<?php
// Heading
$_['heading_title'] = '新着商品';

// Text
$_['text_tax']      = '税別:';
