<?php
$_['heading_title'] = 'レポート';
$_['text_success'] = '成功しました：レポートが変更されました！';
$_['text_type'] = 'レポートの種類を選択する';
$_['text_filter'] = 'フィルター';
?>
