<?php
// Heading
$_['heading_title']    = '合計';

// Text
$_['text_extension']       = '拡張機能';
$_['text_success']     = '成功: 合計を更新しました!';
$_['text_edit']        = '合計の編集';

// Entry
$_['entry_status']     = 'ステータス';
$_['entry_sort_order'] = '表示順';

// Error
$_['error_permission'] = '警告: 合計を更新する権限がありません!';
