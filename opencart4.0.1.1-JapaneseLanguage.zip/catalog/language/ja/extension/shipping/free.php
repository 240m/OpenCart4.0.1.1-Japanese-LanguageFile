<?php
// Text
$_['text_title']       = '送料無料';
$_['text_description'] = '配送料(送料無料)';
