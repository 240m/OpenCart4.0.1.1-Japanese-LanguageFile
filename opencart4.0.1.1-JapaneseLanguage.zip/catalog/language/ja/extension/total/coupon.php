<?php
// Heading
$_['heading_title'] = 'クーポンコードを使用する';

// Text
$_['text_coupon']   = 'クーポン利用 (%s)';
$_['text_success']  = '成功：クーポン割引が適用されました！';

// Entry
$_['entry_coupon']  = 'クーポンをここに入力してください';

// Error
$_['error_coupon']  = '警告：クーポンは無効、期限切れ、または使用限度に達しています。';
$_['error_empty']   = '警告：クーポンコードを入力してください';