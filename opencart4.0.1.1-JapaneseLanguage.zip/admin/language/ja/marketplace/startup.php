<?php
$_['heading_title'] = 'スタートアップ';
$_['text_success'] = '成功しました：スタートアップを変更しました！';
$_['text_list'] = 'スタートアップリスト';
$_['column_code'] = 'スタートアップコード';
$_['column_sort_order'] = 'ソート順';
$_['column_action'] = 'アクション';
$_['error_permission'] = '警告あなたにはスタートアップを変更する権限がありません！';
?>
