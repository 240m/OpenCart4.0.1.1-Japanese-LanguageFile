<?php
$_['heading_title'] = 'アカウント登録';
$_['text_account'] = 'アカウント';
$_['text_register'] = '登録';
$_['text_account_already'] = 'すでにアカウントをお持ちの方は、<a href="%s">ログインページ</a>でログインしてください。';
$_['text_your_details'] = 'お客様の個人情報';
$_['text_newsletter'] = 'ニュースレター';
$_['text_your_password'] = 'パスワード';
$_['text_agree'] = '<a href="%s" class="modal-link"><b>%s</b></a> を読み、これに同意します。';
$_['entry_customer_group'] = '顧客グループ';
$_['entry_firstname'] = 'ファーストネーム';
$_['entry_lastname'] = 'ラストネーム';
$_['entry_email'] = '電子メール';
$_['entry_telephone'] = '電話番号';
$_['entry_newsletter'] = 'サブスクライブ';
$_['entry_password'] = 'パスワード';
$_['entry_confirm'] = 'パスワードの確認';
$_['error_token'] = '警告登録トークンが無効です！';
$_['error_exists'] = '警告E-Mailアドレスはすでに登録されています！';
$_['error_customer_group'] = 'カスタマーグループが有効でないようです！';
$_['error_firstname'] = 'ファーストネームは、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = 'Last Nameは1文字以上32文字以内で入力してください！';
$_['error_email'] = 'E-Mailアドレスが有効でないようです！';
$_['error_telephone'] = '電話番号は、3文字以上32文字以下で入力してください！';
$_['error_custom_field'] = 'sが必要です！';
$_['error_regex'] = 'sは有効な入力ではありません！';
$_['error_password'] = 'パスワードは、4文字以上20文字以下で設定してください！';
$_['error_agree'] = '警告sに同意する必要があります！';
?>
