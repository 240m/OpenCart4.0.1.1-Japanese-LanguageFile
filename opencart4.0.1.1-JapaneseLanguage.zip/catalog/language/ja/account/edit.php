<?php
$_['heading_title'] = 'マイアカウント情報';
$_['text_account'] = 'アカウント';
$_['text_edit'] = '編集情報';
$_['text_your_details'] = 'お客様の個人情報';
$_['text_success'] = '成功しました：お客様のアカウントは正常に更新されました。';
$_['entry_firstname'] = 'ファーストネーム';
$_['entry_lastname'] = 'ラストネーム';
$_['entry_email'] = '電子メール';
$_['entry_telephone'] = '電話番号';
$_['error_token'] = '警告：Edit tokenが無効です！';
$_['error_exists'] = '警告メールアドレスはすでに登録されています！';
$_['error_firstname'] = 'ファーストネームは、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = 'Last Nameは1文字以上32文字以内で入力してください！';
$_['error_email'] = 'E-Mailアドレスが有効でないようです！';
$_['error_telephone'] = '電話番号は、3文字以上32文字以下で入力してください！';
$_['error_custom_field'] = 'sが必要です！';
$_['error_regex'] = 'sは有効な入力ではありません！';
?>
