<?php
$_['text_subject'] = '%s - 製品レビュー';
$_['text_waiting'] = '新製品のレビューが待っていますね。';
$_['text_product'] = '製品です：';
$_['text_reviewer'] = 'レビュアー';
$_['text_rating'] = '評価する：';
$_['text_review'] = '復習用テキストです：';
?>
