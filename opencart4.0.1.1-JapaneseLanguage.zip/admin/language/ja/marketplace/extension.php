<?php
$_['heading_title'] = 'エクステンション';
$_['text_success'] = '成功しました：エクステンションを変更しました！';
$_['text_list'] = 'エクステンションリスト';
$_['text_type'] = 'エクステンションの種類を選ぶ';
$_['text_filter'] = 'フィルター';
?>
