<?php
$_['heading_title'] = 'メンテナンス';
$_['text_maintenance'] = 'メンテナンス';
$_['text_message'] = '<h1 style="text-align:center;">現在、定期メンテナンスを行っています。<br/>できるだけ早く復帰する予定です。</h1> <h1 style="textign center;">ただいま定期メンテナンス中です。';
?>
