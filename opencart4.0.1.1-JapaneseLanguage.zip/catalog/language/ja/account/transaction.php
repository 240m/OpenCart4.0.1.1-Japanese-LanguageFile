<?php
$_['heading_title'] = 'お客様のお取引について';
$_['column_date_added'] = '追加された日付';
$_['column_description'] = '商品説明';
$_['column_amount'] = '金額(%s)';
$_['text_account'] = 'アカウント';
$_['text_transaction'] = 'お客様のお取引について';
$_['text_total'] = '現在のバランスは';
$_['text_no_results'] = '取引はしていないのですね！';
?>
