<?php
// Heading
$_['heading_title']  = '人気商品';

// Text
$_['text_tax']      = '税別:';
