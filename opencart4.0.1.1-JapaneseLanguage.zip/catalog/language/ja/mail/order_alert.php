<?php
$_['text_subject'] = '%s - 注文 %s';
$_['text_received'] = '注文が入りました。';
$_['text_order_id'] = 'オーダーIDです：';
$_['text_date_added'] = '日付が追加されました：';
$_['text_order_status'] = '注文状況です：';
$_['text_product'] = '製品です：';
$_['text_total'] = 'トタル：';
$_['text_comment'] = 'ご注文時のコメントです：';
?>
