<?php
$_['heading_title'] = 'エーピーアイ';
$_['text_success'] = '成功です：APIを変更しました！';
$_['text_list'] = 'API一覧';
$_['text_add'] = 'APIを追加する';
$_['text_edit'] = 'APIを編集する';
$_['text_ip'] = '以下では、APIへのアクセスを許可するIPのリストを作成することができます。あなたの現在のIPは %s です';
$_['column_username'] = 'APIユーザー名';
$_['column_status'] = 'ステータス';
$_['column_token'] = 'トークン';
$_['column_ip'] = 'IP';
$_['column_date_added'] = '追加された日付';
$_['column_date_modified'] = '修正日';
$_['column_action'] = 'アクション';
$_['entry_username'] = 'APIユーザー名';
$_['entry_key'] = 'APIキー';
$_['entry_status'] = 'ステータス';
$_['entry_ip'] = 'IP';
$_['error_permission'] = '警告あなたはAPIを変更する権限を持っていません！';
$_['error_username'] = 'API Usernameは、3文字以上20文字以下で入力してください！';
$_['error_key'] = 'APIキーは64文字以上256文字以下で入力してください！';
$_['error_ip'] = '少なくとも1つのIPが許可リストに追加されている必要があります！';
?>
