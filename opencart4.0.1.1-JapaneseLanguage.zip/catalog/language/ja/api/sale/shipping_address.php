<?php
$_['text_success'] = '成功しました：配送先が設定されました！';
$_['error_firstname'] = 'ファーストネームは、1文字以上32文字以内で入力してください！';
$_['error_lastname'] = 'Last Nameは1文字以上32文字以内で入力してください！';
$_['error_address_1'] = 'アドレス1は、3文字以上128文字以下とします！';
$_['error_city'] = 'Cityは3文字以上128文字以下で入力してください！';
$_['error_postcode'] = '郵便番号は、この国のために2文字以上10文字以下で入力してください！';
$_['error_country'] = '国を選択してください！';
$_['error_zone'] = '地域/州を選択してください！';
$_['error_custom_field'] = 'sが必要です！';
$_['error_regex'] = 'sは有効な入力ではありません！';
$_['error_shipping'] = 'ご注意送料がかかる商品はございません';
?>
