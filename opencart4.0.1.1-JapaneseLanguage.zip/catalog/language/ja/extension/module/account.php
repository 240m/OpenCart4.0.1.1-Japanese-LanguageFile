<?php
// Heading
$_['heading_title']    = 'アカウント情報';

// Text
$_['text_register']    = 'アカウント登録';
$_['text_login']       = 'ログイン';
$_['text_logout']      = 'ログアウト';
$_['text_forgotten']   = 'パスワードをお忘れの方は･･･';
$_['text_account']     = 'アカウント情報';
$_['text_edit']        = 'アカウント情報の変更';
$_['text_password']    = 'パスワードの変更';
$_['text_address']     = 'アドレス帳';
$_['text_wishlist']    = 'ウイッシュリスト';
$_['text_order']       = '注文履歴';
$_['text_download']    = 'ダウンロード';
$_['text_reward']      = 'ポイント照会';
$_['text_return']      = '返品履歴';
$_['text_transaction'] = '取引履歴';
$_['text_newsletter']  = 'ニュースレターの購読/解除';
$_['text_recurring']   = '定期支払い';
