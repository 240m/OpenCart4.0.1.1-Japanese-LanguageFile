<?php
$_['heading_title'] = 'GDPR承認';
$_['text_success'] = '成功しました：GDPRの承認を修正しました！';
$_['text_list'] = 'GDPR承認リスト';
$_['text_info'] = '<strong>GDPR</strong>アカウント削除リクエストは、<strong>%s days</strong>後に処理されるため、不正検出、チャージバック、返金などの処理が可能です。';
$_['text_approve'] = '承認する';
$_['text_deny'] = '否定する';
$_['text_delete'] = '削除';
$_['text_unverified'] = '未確認';
$_['text_pending'] = '保留中';
$_['text_processing'] = '加工方法';
$_['text_complete'] = 'コンプリート';
$_['text_denied'] = '否定的';
$_['text_export'] = '輸出';
$_['text_remove'] = '削除';
$_['text_filter'] = 'フィルター';
$_['column_email'] = '電子メール';
$_['column_request'] = 'リクエスト';
$_['column_status'] = 'ステータス';
$_['column_date_added'] = '追加された日付';
$_['column_action'] = 'アクション';
$_['entry_email'] = '電子メール';
$_['entry_action'] = 'アクション';
$_['entry_status'] = 'ステータス';
$_['entry_date_from'] = '日付 From';
$_['entry_date_to'] = '日付 To';
$_['error_permission'] = '警告GDPRの承認を変更する権限がありません！';
?>
