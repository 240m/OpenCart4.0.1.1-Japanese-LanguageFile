<?php
//made by bestshop24h,support email:support@bestshop24h.com  or 95672639@qq.com
// Text
$_['text_title']    = 'Australia Post';