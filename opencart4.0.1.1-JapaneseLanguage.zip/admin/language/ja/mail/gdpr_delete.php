<?php
$_['text_subject'] = 's - GDPR リクエストが処理されました！';
$_['text_request'] = 'アカウント削除のお願い';
$_['text_hello'] = 'こんにちは<strong>%s</strong>です、';
$_['text_user'] = 'ユーザー';
$_['text_delete'] = 'お客様のGDPRデータ削除リクエストはこれで完了です。';
$_['text_contact'] = '詳しくは、こちらのストアオーナーにお問い合わせください：';
$_['text_thanks'] = 'ありがとうございます、';
$_['button_contact'] = 'お問い合わせ';
?>
