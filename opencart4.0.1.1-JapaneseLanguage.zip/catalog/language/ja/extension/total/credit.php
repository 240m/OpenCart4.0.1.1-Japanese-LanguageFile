<?php
// Text
$_['text_credit']   = '信用取引(後払い)';
$_['text_order_id'] = 'ご注文番号: %s';
