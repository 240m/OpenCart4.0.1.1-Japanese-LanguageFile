<?php
// Text
$_['text_title']       = '一律料金';
$_['text_description'] = '配送料(一律料金)';
