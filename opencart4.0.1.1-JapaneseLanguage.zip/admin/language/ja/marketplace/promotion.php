<?php
$_['text_recommended'] = 'おすすめ';
$_['text_install'] = 'インストール';
$_['text_uninstall'] = 'アンインストール';
$_['text_delete'] = '削除';
?>
