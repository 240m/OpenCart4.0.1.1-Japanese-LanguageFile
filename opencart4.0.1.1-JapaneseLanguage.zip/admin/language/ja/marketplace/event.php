<?php
$_['heading_title'] = 'イベント情報';
$_['text_success'] = '成功しました：イベントを修正しました！';
$_['text_list'] = 'イベント一覧';
$_['text_event'] = 'イベントは、ストアのデフォルト機能をオーバーライドするためにエクステンションによって使用されます。問題がある場合は、ここでイベントを無効化または有効化することができます。';
$_['text_info'] = 'イベント情報';
$_['column_code'] = 'イベントコード';
$_['column_sort_order'] = 'ソート順';
$_['column_action'] = 'アクション';
$_['entry_description'] = '商品説明';
$_['entry_trigger'] = 'トリガー';
$_['entry_action'] = 'アクション';
$_['error_permission'] = '警告あなたはイベントを変更する権限を持っていません！';
?>
