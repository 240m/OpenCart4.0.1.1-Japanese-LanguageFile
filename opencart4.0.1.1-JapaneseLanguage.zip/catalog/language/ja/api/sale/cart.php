<?php
$_['text_success'] = '成功しました：ショッピングカートを変更しました！';
$_['text_subscription'] = 'サブスクリプション';
$_['text_subscription_trial'] = '%s 毎 %d %s(s)に %d 回の支払をする。';
$_['text_subscription_duration'] = '%s %d %s(s)ごとに %d 回の支払いを行う。';
$_['text_subscription_cancel'] = 'キャンセルされるまで %d %s(s)ごとに %s';
$_['text_day'] = '日';
$_['text_week'] = '週';
$_['text_semi_month'] = '半月';
$_['text_month'] = '月';
$_['text_year'] = 'イヤー';
$_['text_for'] = '%s ギフト券';
$_['error_stock'] = 'がついている商品は、ご希望の数量がない、または在庫がない商品です！';
$_['error_minimum'] = 'sの最小注文額は%sです！';
$_['error_store'] = '選択した店舗で商品を購入することができない！';
$_['error_required'] = 'sが必要です！';
$_['error_product'] = '警告製品が見つかりませんでした！';
$_['error_subscription'] = '加入プランを選択してください！';
?>
