<?php
$_['text_success'] = '成功しました：支払い方法が設定されました！';
$_['error_payment_address'] = 'ご注意支払い先が必要です！';
$_['error_payment_method'] = 'ご注意お支払い方法が必要です！';
$_['error_no_payment'] = 'ご注意お支払い方法はお選びいただけません！';
$_['error_product'] = 'ご注意製品が必要です！';
?>
